/* jQuery.setWidthFontsize.min.js ver.1.0 : jQuery plugin , created by INDETAIL.co.jp - takagi 2015.05.30 , source : https://github.com/ , MIT Licecse */
/*    USEAGE:  in html file, set class "w-xxx" where you need. */
/*    EXAMPLE-1: <div class="w-120"> ---> <div class="w-120" style="width: 120px"> */
/*    EXAMPLE-2: <div class="w-60p" style="margin: 0 auto;"> ---> <div class="w-120" style="margin: 0 auto; width: 60%"> */
/*    EXAMPLE-3: <div class="f-18"> ---> <div class="f-18" style="margin: 0 auto; font-size: 18px"> */
/*    EXAMPLE-4: <div class="f-1.2em"> ---> <div class="f-1.2em" style="margin: 0 auto; font-size: 1.2em"> */

$(function(){

    // width設定
    if( $('[class*=w\-]').length > 0 ){ // w-*** クラス設定があったら
        $('[class*=w\-]').each(function() { // w-*** クラスを個別に取得
            var classes = $(this).attr('class').split(' '); // w-*** クラスが含まれている部分を配列化
            var len = classes.length; // 配列の長さを取得
            var cname = ''; // クラス名を代入する変数を初期化
            var cwidth = 0; // width設定値を初期化
            var unit = 'px'; // デフォルトの単位を指定
            for(var i=0;i<len;i++){ // 配列を走査
                if(classes[i].match(/^w\-/i)){ // w-で始まるクラスがあったら
                    cname = classes[i]; // クラス名を取得して代入
                    break; // 見つかった時点でループを停止
                }
            }
            cwidth = cname.replace(/w\-/i,''); // w-*** クラスから***を取得
            var res = set_unit('width', cwidth); // 単位設定関数で数値+単位を取得
            $(this).css('width', res['val'] + res['unit']); // tagにstyleを追加設定する
        });
    }
    
    // font-size設定
    if( $('[class*=f-]').length > 0 ){
        $('[class*=f-]').each(function() {
            var classes = $(this).attr('class').split(' ');
            var len = classes.length;
            var cname = '';
            var fsize = 0;
            var unit = 'px';
            for(var i=0;i<len;i++){
                if(classes[i].match(/^f\-/i)){
                    cname = classes[i];
                    break;
                }
            }
            fsize = cname.replace(/f\-/i,'');
            var res = set_unit('font', fsize);
            $(this).css('font-size', res['val'] + res['unit']);
        });
    }
    
    // 単位設定関数
    /* param: type: width/font, cval: 設定値
       指定可能単位：
        % (パーセンテージ)
        em (親要素の相対値)
        rem (root要素(html)の相対値)
        ex (1ex=欧文の小文字xの高さ)
        mm (ミリメートル)
        cm (センチメートル)
        in (インチ 1in=2.54cm)
        pt (ポイント 1pt=1/72inch=0.352778mm, 72pt=1in)
        pc (パイカ 1pc=12px)
        px (画素数による絶対値)
    */
    function set_unit(type, cval) {
        if(type=='width'){
            var unitArray = [null,'px','p','%','em','ex','mm','cm','in','pt','pc']; // widthの単位配列
        }else if(type=='font'){
            var unitArray = [null,'px','p','%','em','ex','rem']; // fontの単位配列
        }
        var unit = cval.match(/\D+$/); // 単位のみ（末尾の数字以外の部分）を抜き出す
        var val = cval.replace(unit, ''); // 数字列(単位以外）を抜き出す
        if($.inArray(unit, unitArray)) { // 単位が配列内にあればその単位とする
            if(unit=='null' || unit==''){ // 単位の設定がない場合はpxとする
                unit = 'px';
            } else if (unit=='p'){ // 単位がpの場合は%とする
                unit = '%';
            }
            if(type == 'width' && unit == '%' && val > 100) { // width設定で単位が%の場合は最大値を100%とする
                val = 100;
            }
        }else{ // 単位が配列内になければすべてpxとする
            unit = 'px';
        }
        var res = {'val': val, 'unit': unit}; // 数値と+単位を配列に格納して返す
        return res;
    }
});
